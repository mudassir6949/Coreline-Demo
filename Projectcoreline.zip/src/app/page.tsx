
export default function Home() {
  return (
   <>
    <h1 className="text-2xl text-center"> </h1>
    </>
  );
}

